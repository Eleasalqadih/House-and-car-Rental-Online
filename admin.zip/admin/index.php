<?php
	include 'inc/header.php';
	Session::checkAdmin();
	include 'inc/sidebar.php';
 ?>
 <?php
 if (isset($_POST['logout'])) {
	if (session_status()===PHP_SESSION_ACTIVE){
		session_unset();
		session_destroy();
	}
	 header("location:../index.php");
	 exist();
 }
  ?>
<div class="main-panel">
<?php
	include 'inc/topnav.php';
	include 'inc/main_content.php';
	include 'inc/footer.php';
 ?>
</div>
<?php
	include 'inc/jsarea.php';
 ?>

Home

Owners

Tenants

All Users Message

About Page

Cover Image


Notice: session_start(): Ignoring session_start() because a session is already active in C:\xampp\htdocs\House11\admin\index.php on line 8

Fatal error: Uncaught Error: Call to undefined function session_destory() in C:\