
    <div class="sidebar" data-background-color="white" data-active-color="danger">


    	<div class="sidebar-wrapper">
            <div class="logo" style="color:red">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Rent Easy
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="index.php">
                        <i class="ti-layout-grid2"></i>
                        <p>Home</p>
                    </a>
                </li>
                <li>
                    <a href="allowner.php">
                        <i class="ti-user"></i>
                        <p>Owners</p>
                    </a>
                </li>
                <li>
                    <a href="alltenant.php">
                        <i class="ti-user"></i>
                        <p>Tenants</p>
                    </a>
                </li>
                <li>
                    <a href="allmessage.php">
                        <i class="ti-user"></i>
                        <p>All Users Message</p>
                    </a>
                </li>
                <li>
                    <a href="about.php">
                        <i class="ti-user"></i>
                        <p>About Page</p>
                    </a>
                </li>
                <li>
                    <a href="cover.php">
                        <i class="ti-user"></i>
                        <p>Cover Image</p>
                    </a>
                </li>
                <!-- <li>
                    <a href="allhouse.php">
                        <i class="ti-user"></i>
                        <p>All House List</p>
                    </a>
                </li> -->
            </ul>
    	</div>
    </div>
