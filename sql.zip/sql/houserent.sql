-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2019 at 02:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `houserent`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(252) NOT NULL,
  `username` varchar(252) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `email`, `username`, `password`) VALUES
(2, 'admin@gmail.com', 'admin', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_house`
--

CREATE TABLE `tbl_house` (
  `id` int(50) NOT NULL,
  `owner_id` int(50) NOT NULL,
  `tenant_id` int(50) NOT NULL,
  `address` text NOT NULL,
  `road_no` varchar(252) NOT NULL,
  `house_no` varchar(252) NOT NULL,
  `rental_value` varchar(50) NOT NULL,
  `house_type` varchar(50) NOT NULL,
  `floor` varchar(252) NOT NULL,
  `bedroom` varchar(50) NOT NULL,
  `dinning_room` varchar(52) NOT NULL,
  `bathroom` varchar(50) NOT NULL,
  `kitchen` varchar(52) NOT NULL,
  `balconies` varchar(52) NOT NULL,
  `description` text NOT NULL,
  `active_status` int(11) NOT NULL,
  `img_1` varchar(252) NOT NULL,
  `img_2` varchar(252) NOT NULL,
  `img_3` varchar(252) NOT NULL,
  `location` varchar(255) NOT NULL
);

--
-- Dumping data for table `tbl_house`
--

INSERT INTO `tbl_house` (`id`, `owner_id`, `tenant_id`, `address`, `road_no`, `house_no`,  `location`, `rental_value`, `house_type`, `floor`, `bedroom`, `dinning_room`, `bathroom`, `kitchen`, `balconies`, `description`, `active_status`, `img_1`, `img_2`, `img_3`) VALUES
(34, 53, 0, 'Albaha', '5', '12', 'https://maps.app.goo.gl/tmNDkngXwTXK24R48', '16000 SRA', 'Family', '4', '0', '', '0', '', '', 'la la', 0, 'uploads/House/Family.jpeg', 'uploads/House/Family_ho1.jpeg', ''),
(35, 53, 0, 'Albaha', '2', '3', 'https://maps.app.goo.gl/tmNDkngXwTXK24R48', '11000 SRA', 'Family', '2', '0', '', '0', '', '', 'la ', 0, 'uploads/House/Family1.jpeg', 'uploads/House/Family_ho3.jpeg', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_message`
--

CREATE TABLE `car` (
  `id` int(50) NOT NULL,
  `owner_id` int(50) NOT NULL,
  `tenant_id` int(50) NOT NULL,
  `car_type` text NOT NULL,
  `rental_type` varchar(252) NOT NULL,
  `plate_number` varchar(252) NOT NULL,
  `car_color` varchar(50) NOT NULL,
  `car_number` varchar(50) NOT NULL,
  `Car_model` varchar(252) NOT NULL,
  `active_status` int(11) NOT NULL,
  `img_1` varchar(252) NOT NULL,
  `img_2` varchar(252) NOT NULL,
  `img_3` varchar(252) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `car` (`id`, `owner_id`, `tenant_id`, `car_type`, `rental_type`, `Plate_number`, `car_number`, `car_color`, `Car_model`, `active_status`, `img_1`, `img_2`, `img_3`) VALUES
(33, 51, 0, 'Houndai', 'Delay-35 SAR', '109akala', '990', 'Blue','2009', 0, 'uploads/car/Houndai_blue.jpeg','', ''),
(36, 52, 1, 'Houndai', 'Monthely-1000 SAR', '100kao1', '898', 'Black','2010',0, 'uploads/car/Houndai.jpeg', '', ''),
(34, 53, 2, 'BMW', 'Delay-35 SAR', '1090100', '91', 'Weight','2006', 0, 'uploads/car/BMW_weight.jpeg','', ''),
(35, 54, 3, 'BMW', 'Monthely-1000 SAR', '10100191', '891', 'Weight','2020',0, 'uploads/car/BMW_weight1.jpeg', '', '');


CREATE TABLE `tbl_rentpayment`(
  `carP_id` int(50) NOT NULL,
  `tenant_id` int(50) NOT NULL);
  CREATE TABLE `tbl_adminmsg` (
  `email` int(50) NOT NULL,
  `message` int(50) NOT NULL);
--

CREATE TABLE `tbl_message` (
  `id` int(50) NOT NULL,
  `from_id` int(50) NOT NULL,
  `to_id` int(50) NOT NULL,
  `message` text NOT NULL,
  `read_message` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_message`
--

INSERT INTO `tbl_message` (`id`, `from_id`, `to_id`, `message`, `read_message`, `time`) VALUES
(2, 53, 52, 'Your booked request for this <a href=\"housedetails.php?house_id=\"34\">house</a> is rejected by the owner!', 0, '2019-03-12 19:57:03'),
(3, 53, 52, 'Your booked request for this <a href=\"housedetails.php?house_id=47\">house</a> is rejected by the owner!', 0, '2019-03-12 21:42:12'),
(4, 53, 52, 'Your booked request for this <a href=\"housedetails.php?house_id=35\">house</a> is accepted by the owner!', 0, '2019-03-12 21:45:11'),
(5, 53, 52, 'Your booked request for this <a href=\"housedetails.php?house_id=47\">house</a> is rejected by the owner!', 0, '2019-03-13 06:18:37');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rentrequest`
--

CREATE TABLE `tbl_rentrequest` (
  `id` int(50) NOT NULL,
  `house_id` int(50) NOT NULL,
  `car_id` int(50) NOT NULL,
  `tenant_id` int(50) NOT NULL,
  `owner_id` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_rentrequest`
--

INSERT INTO `tbl_rentrequest` (`id`, `house_id`,`car_id`, `tenant_id`, `owner_id`) VALUES
(7, 35, 34, 52, 53),
(10, 38,33 , 52, 53),
(11, 47,36 ,52, 53);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `user` enum('owner','tenant') DEFAULT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `email` varchar(52) NOT NULL,
  `password` varchar(152) NOT NULL,
  `nid` int(20) NOT NULL,
  `address` text NOT NULL,
  `pic` varchar(32) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `account` int(10) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user`, `fname`, `lname`, `email`, `password`, `nid`, `address`, `pic`, `phone_number`, `account`, `description`) VALUES
(52, 'tenant', 'arif', 'khan', 'arif@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, '', '', '', 0, ''),
(53, 'owner', 'shakil', 'ahmed', 'shakil619619@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 0, '', '', '', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_house`
--
ALTER TABLE `tbl_house`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `car`
ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_message`
--
ALTER TABLE `tbl_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rentrequest`
--
ALTER TABLE `tbl_rentrequest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_house`
--
ALTER TABLE `tbl_house`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;


ALTER TABLE `car`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;


--
-- AUTO_INCREMENT for table `tbl_message`
--
ALTER TABLE `tbl_message`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_rentrequest`
--
ALTER TABLE `tbl_rentrequest`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
