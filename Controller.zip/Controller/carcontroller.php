<?php
  include_once 'Controller/baseController.php';

  class carcontroller extends Basecontroller
  {
    public function __construct()
    {
      parent::__construct();
    }

    public function getcardetails(){
      $sql = 'select * from car where active_status = :active_status order by id DESC';
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':active_status',0);
      $query->execute();
      $result = $query->fetchAll();
      return $result;
    }

    public function getCarDetailsByOwner($id)
    {
      $sql = 'select * from car where owner_id=:id order by id DESC';
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':id',$id);
      $query->execute();
      $result = $query->fetchAll();
      return $result;
    }

    public function getCarDetailsByTenant($id)
    {
      $sql = 'select * from car where tenant_id=:id order by id DESC';
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':id',$id);
      $query->execute();
      $result = $query->fetchAll();
      return $result;
    }

    public function getCarDetails_Obj($id){
        $sql = 'select * from car where id = :id';
        $query = $this->db->link->prepare($sql);
        $query->bindParam('id',$id,PDO::PARAM_INT);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);
        return $result;
      }
  
    public function searchCar($min,$max,$data)
    {
      $sql = "SELECT id,car_type,rental_value FROM car WHERE rental_value BETWEEN :min and :max and active_status = :active_status";
      $car_type = 0;
      if (isset($data['car_type'])) {
        $sql = $sql.' and car_type = :car_type';
        $car_type = 1;
      }
      $query = $this->db->link->prepare($sql);
      $query->bindParam(':min', $min, PDO::PARAM_INT);
      $query->bindParam(':max', $max, PDO::PARAM_INT);
      if ($car_type == 1) {
        $query->bindParam(':car_type', $data['car_type'], PDO::PARAM_STR);
      }
      $query->bindValue(':active_status',0);
      $query->execute();
      $result = $query->fetchAll();
      return $result;
    }

    public function sendRequest($carid,$ownerid)
    {
      $tenantid = Session::get('user_id');
      $sql = "insert into tbl_rentrequest(car_id,tenant_id,owner_id) values(:car_id,:tenant_id,:owner_id)";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':car_id',$carid);
      $query->bindValue(':tenant_id',$tenantid);
      $query->bindValue(':owner_id',$ownerid);
      $insert = $query->execute();
      if($insert){
        $msg = 'You got a rent request for this <a href="cardetails.php?car_id='.$carid.'">car</a> from a tenant!';
        $sql = "insert into tbl_message(from_id,to_id,message) values(:from_id,:to_id,:message)";
        $query = $this->db->link->prepare($sql);
        $query->bindValue(':from_id',$tenantid);
        $query->bindValue(':to_id',$ownerid);
        $query->bindValue(':message',$msg);
        $query->execute();
        return 'req_success';
      }
    }

public function checkRequestpayment($carid)
{
 $tenantid = Session::get('user_id');
 $sql = "select tenant_id from tbl_rentpayment where carP_id=:car_id";
 $query = $this->db->link->prepare($sql);
 $query->bindValue(':car_id',$carid);
 $query->execute();
 $result = $query->fetch(PDO::FETCH_ASSOC);
 if($result && isset($result['tenant_id']) && $result['tenant_id'] == $tenantid){
   return 'success';
 }
 else{
  return 'no';
 }
}
    public function checkRequest($carid)
    {
      $tenantid = Session::get('user_id');
      $sql = "select tenant_id from car where id=:car_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':car_id',$carid);
      $query->execute();
      $result = $query->fetch(PDO::FETCH_ASSOC);
      if($result['tenant_id'] == $tenantid){
        return 'booked';
      }

      $sql = "select tenant_id from tbl_rentrequest where tenant_id=:tenant_id and car_id=:car_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':tenant_id',$tenantid);
      $query->bindValue(':car_id',$carid);
      $query->execute();
      $result = $query->fetch(PDO::FETCH_ASSOC);
      return is_array($result) && count($result) > 0 ? 'yes' : 'no';
    }

    public function cancelRequest($carid,$ownerid)
    {
      $tenantid = Session::get('user_id');
      $sql = "delete from tbl_rentrequest where car_id=:car_id and tenant_id=:tenant_id and owner_id=:owner_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':car_id',$carid);
      $query->bindValue(':tenant_id',$tenantid);
      $query->bindValue(':owner_id',$ownerid);
      $query->execute();
    }

    public function totalRequestcar($carid)
    {
      $sql = "select * from tbl_rentrequest where car_id=:car_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':car_id',$carid);
      $query->execute();
      $result = $query->fetchAll(PDO::FETCH_ASSOC);
      return $result;
    }

    public function getUser($id)
    {
      $sql = "select * from tbl_user where id=:id";
      $query = $this->db->link->prepare($sql);
      $query->bindParam('id',$id,PDO::PARAM_INT);
      $query->execute();
      $result = $query->fetchObject(__CLASS__);
      return $result;
    }
    public function updateUser($id,$data,$files)
    {
      $sizenum = 0;
      $extnum = 0;

      $permited = array('jpg', 'jpeg', 'png', 'gif');
      if(isset($files['profile_img'] ) && $files['profile_img']['name'] != '') {

          $file_name = $files['profile_img']['name'];
          $file_size = $files['profile_img']['size'];
          $file_temp = $files['profile_img']['tmp_name'];

          $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);

          if ($file_size>(10*1024*1024)){
              $sizenum++;
              Session::set('sizenum',$sizenum);
              $uploaded_image='';
          }
          else if(in_array($file_ext, $permited) === false) {
              $extnum++;
              Session::set('extnum',$extnum);
              $uploaded_image='';
          }
          else{
              $unique_image = substr(md5(microtime()), 0, 10) . '.' . $file_ext;
              $uploaded_image = "uploads/profile/" . $unique_image;
              move_uploaded_file($file_temp, $uploaded_image);

              $sql = "update tbl_user set fname=:fname, lname=:lname, address=:address, phone_number=:phone_number, nid=:nid, description=:description,pic=:pic where id=:id";
              $query = $this->db->link->prepare($sql);
              $query->bindParam('fname',$data['fname'],PDO::PARAM_STR);
              $query->bindParam('lname',$data['lname'],PDO::PARAM_STR);
              $query->bindParam('address',$data['address'],PDO::PARAM_STR);
              $query->bindParam('phone_number',$data['phone_number'],PDO::PARAM_STR);
              $query->bindParam('nid',$data['nid'],PDO::PARAM_INT);
              $query->bindParam('description',$data['description'],PDO::PARAM_STR);
              $query->bindParam('pic',$uploaded_image,PDO::PARAM_STR);
              $query->bindParam('id',$id,PDO::PARAM_INT);
              $query->execute();
          }
      }
      else{
        print_r($data);
        print_r($id);
        print_r($files);
        $sql = "update tbl_user set fname=:fname, lname=:lname, address=:address, phone_number=:phone_number, nid=:nid, description=:description where id=:id";
        $query = $this->db->link->prepare($sql);
        $query->bindParam('fname',$data['fname'],PDO::PARAM_STR);
        $query->bindParam('lname',$data['lname'],PDO::PARAM_STR);
        $query->bindParam('address',$data['address'],PDO::PARAM_STR);
        $query->bindParam('phone_number',$data['phone_number'],PDO::PARAM_STR);
        $query->bindParam('nid',$data['nid'],PDO::PARAM_INT);
        $query->bindParam('description',$data['description'],PDO::PARAM_STR);
        $query->bindParam('id',$id,PDO::PARAM_INT);
        $query->execute();
      }


    }

    public function acceptrequest($houseid,$tenants_id)
    {
      $act_st = 1;
      $sql = "update car set tenant_id=:tenant_id,active_status=:active_status  where id = :car_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':tenant_id',$tenants_id);
      $query->bindValue(':active_status',$act_st);
      $query->bindValue(':car_id',$carid);

      $query->execute();

      $ownerid = Session::get('user_id');
      $msg = 'Your booked request for this <a href="housedetails.php?house_id='.$carid.'">house</a> is accepted by the owner!';
      $sql = "insert into tbl_message(from_id,to_id,message) values(:from_id,:to_id,:message)";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':from_id',$ownerid);
      $query->bindValue(':to_id',$tenants_id);
      $query->bindValue(':message',$msg);
      $query->execute();
    }

    public function rejectrequest($carid,$tenants_id)
    {
      $sql = "delete from tbl_rentrequest where house_id = :house_id and tenant_id=:tenant_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':house_id',$carid);
      $query->bindValue(':tenant_id',$tenants_id);
      $query->execute();

      $ownerid = Session::get('user_id');
      $msg = 'Your booked request for this <a href="housedetails.php?house_id='.$carid.'">house</a> is rejected by the owner!';
      $sql = "insert into tbl_message(from_id,to_id,message) values(:from_id,:to_id,:message)";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':from_id',$ownerid);
      $query->bindValue(':to_id',$tenants_id);
      $query->bindValue(':message',$msg);
      $query->execute();
    }
    
    public function freeCar($carid)
    {
      $sql = "update car set tenant_id=:tenant_id, active_status = :active_status where id=:car_id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':tenant_id',0);
      $query->bindValue(':active_status',0);
      $query->bindValue(':car_id',$carid);
      $query->execute();
    }

    public function deleteCar($id,$ownerid){
      $sql = "delete from tbl_car where id =:id";
      $query = $this->db->link->prepare($sql);
      $query->bindValue(':id',$id);
      $query->execute();
      header("Location: http://localhost/carrent/owner_profile.php?id=".$ownerid);
    }
  }
?>