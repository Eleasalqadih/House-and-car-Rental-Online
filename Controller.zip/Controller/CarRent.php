<?php
include_once 'Controller/baseController.php';

class CarRent extends baseController
{
    function __construct()
    {
        parent::__construct();
    }

    public function addRent($value, $files)
    {
        $owner_id = Session::get('user_id');
        $car_type = $value['car_type'];
        $rental_type = $value['rental_type'];
        $car_color = $value['car_color'];
        $car_number = $value['car_number'];
        $plate_number = $value['plate_number'];
        $car_model = $value['car_model'];
        $rental_price = ($rental_type === 'daily') ? 35 : 1000;  // السعر حسب نوع الإيجار

        if (empty($car_type) || empty($rental_type) || empty($car_color) || empty($car_number) || empty($plate_number) || empty($car_model)) {
            return 'notfill';
        }

        $sizenum = 0;
        $extnum = 0;
        $permited = array('jpg', 'jpeg', 'png', 'gif');
        
        if(isset($files['img_2'] ) && $files['img_2']['name'] != '') {

            $file_name = $files['img_2']['name'];
            $file_size = $files['img_2']['size'];
            $file_temp = $files['img_2']['tmp_name'];
  
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
  
            if ($file_size>(10*1024*1024)){
                $sizenum++;
                Session::set('sizenum',$sizenum);
                $uploaded_image_2='';
            }
            else if(in_array($file_ext, $permited) === false) {
                $extnum++;
                Session::set('extnum',$extnum);
                $uploaded_image_2='';
            }
            else{
                $unique_image = substr(md5(microtime()), 0, 10) . '.' . $file_ext;
                $uploaded_image_2 = "uploads/" . $unique_image;
                move_uploaded_file($file_temp, $uploaded_image_2);
            }
        }
        else{
          $uploaded_image_2='';
        }
  
  
        if(isset($files['img_3']) && $files['img_3']['name'] != '') {
  
            $file_name = $files['img_3']['name'];
            $file_size = $files['img_3']['size'];
            $file_temp = $files['img_3']['tmp_name'];
  
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
  
  
            if ($file_size > (10*1024*1024)){
                $sizenum++;
                Session::set('sizenum',$sizenum);
                $uploaded_image_3='';
            }
            else if(in_array($file_ext, $permited) === false) {
                $extnum++;
                Session::set('extnum',$extnum);
                $uploaded_image_3='';
            }
            else{
              $unique_image = substr(md5( microtime()), 0, 10) . '.' . $file_ext;
              $uploaded_image_3 = "uploads/" . $unique_image;
              move_uploaded_file($file_temp, $uploaded_image_3);
            }
        }
        else{
          $uploaded_image_3='';
        }
  
  
        if(isset($files['img_1']) && $files['img_1']['name'] != '' ) {
  
            $file_name = $files['img_1']['name'];
            $file_size = $files['img_1']['size'];
            $file_temp = $files['img_1']['tmp_name'];
  
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
  
            if ($file_size > (10*1024*1024)){
                $sizenum++;
                Session::set('sizenum',$sizenum);
                $uploaded_image_1='';
            }
            else if(in_array($file_ext, $permited) === false) {
                $extnum++;
                Session::set('extnum',$extnum);
                $uploaded_image_1='';
            }
            else{
              $unique_image = substr(md5( microtime()), 0, 10) . '.' . $file_ext;
              $uploaded_image_1 = "uploads/" . $unique_image;
              move_uploaded_file($file_temp, $uploaded_image_1);
            }
        }
        else{
          $uploaded_image_1='';
        }
  

        // استعلام SQL لإدخال بيانات السيارة
        $sql = "INSERT INTO car (owner_id, car_type, rental_type, car_number,car_color,plate_number,car_model, img_1, img_2, img_3)
                VALUES (:owner_id, :car_type, :rental_type, :car_number, :car_color,:plate_number,:car_model, :img_1, :img_2, :img_3)";
        $query = $this->db->link->prepare($sql);

        $query->bindValue(':owner_id', $owner_id);
        $query->bindValue(':car_type', $car_type);
        $query->bindValue(':rental_type', $rental_type);
        $query->bindValue(':car_number', $car_number);
        $query->bindValue(':car_color', $car_color);
        $query->bindValue(':plate_number', $car_number);
        $query->bindValue(':car_model', $car_color);
        $query->bindValue(':img_1', $uploaded_image_1);
        $query->bindValue(':img_2', $uploaded_image_2);
        $query->bindValue(':img_3', $uploaded_image_3);
        $result = $query->execute();
        if ($result) {
            return 'success';
        } else {
            return 'JEIDPOPO3E3E0E-3E0';
        }
    }
}
?>