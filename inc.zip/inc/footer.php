<footer>
  <div class="footer_main container">
    <p class="text-center">Copyright 2024 by Cool Data. All Rights Reserved.</p>
  </div>
</footer>



</div>

<script src="assets/js/jquery.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/proper.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/bootstrap.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/chosen.jquery.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/slick.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/jquery-ui.min.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/main.js?ver=<?php echo time();?>" charset="utf-8"></script>
<script src="assets/js/myplugins.js?ver=<?php echo time();?>" charset="utf-8"></script>
</body>
</html>
