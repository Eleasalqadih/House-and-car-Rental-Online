<div class="heading_title">
  <h3 class="text-center"><?php echo $title; ?></h3>
  <p class="text-center">
    <span style="height:<?php echo $h; ?>;"></span>
    <i class="fas fa-snowflake"></i>
    <span style="height:<?php echo $h; ?>;"></span>
  </p>
</div>
